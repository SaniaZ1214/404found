import 'package:flutter/material.dart';

void main() {
  runApp(const FunFactsApp());
}

class FunFactsApp extends StatelessWidget {
  const FunFactsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Fun Facts About Me',
      home: const FunFactsHome(),
    );
  }
}

class FunFactsHome extends StatefulWidget {
  const FunFactsHome({super.key});

  @override
  State<FunFactsHome> createState() => _FunFactsHomeState();
}

class _FunFactsHomeState extends State<FunFactsHome> {
  int _counter = 0;
  String _fact = 'Tap the button to reveal a fun fact about me';

  final List<String> _facts = [
    "I love sports cars",
    "I love spending time in nature",
    "Having a walk with mum at the end of the day makes me feel relaxed",
    "Reading fiction is something I like the most in books",
    "Visiting UAE was the worst phase of my life",
  ];

  void _showFact() {
    setState(() {
      _fact = _facts[_counter % _facts.length];
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Fun Facts About Me'),
        backgroundColor: Colors.lightBlueAccent,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              const CircleAvatar(
                radius: 60,
                backgroundImage: NetworkImage(
                  'https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.istockphoto.com%2Fillustrations%2Ffun-facts-icon&psig=AOvVaw3gcrZjwTMy47p3A78dVOwd&ust=1745317897609000&source=images&cd=vfe&opi=89978449&ved=0CBQQjRxqFwoTCOC79P316IwDFQAAAAAdAAAAABAE',
                ),
              ),
              const SizedBox(height: 28),
              Text(
                "Hi I am Sania",
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 20),
              Text(
                _fact,
                style: const TextStyle(fontSize: 18),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _showFact,
                child: const Text('Show Fun Fact'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
